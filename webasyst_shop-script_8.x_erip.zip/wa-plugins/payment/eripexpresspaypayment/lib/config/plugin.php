<?php
return array(
    'name'        => 'Эксресс платежи: ЕРИП',
    'description' => 'Прием платежей через ЕРИП',
    'icon'        => 'img/erip.png',
    'logo'        => 'img/erip.png',
    'vendor'      => 'webasyst',
    'version'     => '2.5.0',
);